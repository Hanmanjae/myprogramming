package model;

public class MenuVO {
	
	int no;
	String menuname;
	int menuno;
	int menuprice;
	
	public MenuVO() {
		super();
	}

	public MenuVO(String menuname, int menuprice) {
		super();
		this.menuname = menuname;
		this.menuprice = menuprice;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getMenuname() {
		return menuname;
	}

	public void setMenuname(String menuname) {
		this.menuname = menuname;
	}

	public int getMenuno() {
		return menuno;
	}

	public void setMenuno(int menuno) {
		this.menuno = menuno;
	}

	public int getMenuprice() {
		return menuprice;
	}

	public void setMenuprice(int menuprice) {
		this.menuprice = menuprice;
	}
	
	
	

}
