package model;

public class PayVO {

	private int ordertbno;
	private int payall;
	private int payreceived;
	private int payreceive;
	private int paychange;
	private String orderDate;

	public PayVO() {
		super();
	}

	public PayVO(int ordertbno, int payall, int payreceived, int payreceive, int paychange, String orderDate) {
		super();
		this.ordertbno = ordertbno;
		this.payall = payall;
		this.payreceived = payreceived;
		this.payreceive = payreceive;
		this.paychange = paychange;
		this.orderDate = orderDate;
	}

	public int getOrdertbno() {
		return ordertbno;
	}

	public void setOrdertbno(int ordertbno) {
		this.ordertbno = ordertbno;
	}

	public int getPayall() {
		return payall;
	}

	public void setPayall(int payall) {
		this.payall = payall;
	}

	public int getPayreceived() {
		return payreceived;
	}

	public void setPayreceived(int payreceived) {
		this.payreceived = payreceived;
	}

	public int getPayreceive() {
		return payreceive;
	}

	public void setPayreceive(int payreceive) {
		this.payreceive = payreceive;
	}

	public int getPaychange() {
		return paychange;
	}

	public void setPaychange(int paychange) {
		this.paychange = paychange;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	@Override
	public String toString() {
		return "PayVO [ordertbno=" + ordertbno + ", payall=" + payall + ", payreceived=" + payreceived + ", payreceive="
				+ payreceive + ", paychange=" + paychange + ", orderDate=" + orderDate + ", toString()="
				+ super.toString() + "]";
	}

}
