package model;

public class OrderVO {

	private int orderno;
	private String ordermname;
	private int ordermcount;
	private int ordermprice;
	private int ordertbno;
	private String orderDate;

	public OrderVO() {
		super();
	}

	public OrderVO(int orderno) {
		super();
		this.orderno = orderno;
	}

	public OrderVO(String ordermname, int ordermcount, int ordermprice, int ordertbno) {
		super();
		this.ordermname = ordermname;
		this.ordermcount = ordermcount;
		this.ordermprice = ordermprice;
		this.ordertbno = ordertbno;
	}

	public OrderVO(int orderno, String ordermname, int ordermcount, int ordermprice, int ordertbno) {
		super();
		this.orderno = orderno;
		this.ordermname = ordermname;
		this.ordermcount = ordermcount;
		this.ordermprice = ordermprice;
		this.ordertbno = ordertbno;
	}
	

	public OrderVO(String ordermname, int ordermcount, int ordermprice, int ordertbno, String orderDate) {
		super();
		this.ordermname = ordermname;
		this.ordermcount = ordermcount;
		this.ordermprice = ordermprice;
		this.ordertbno = ordertbno;
		this.orderDate = orderDate;
	}

	public OrderVO(int orderno, String ordermname, int ordermcount, int ordermprice, int ordertbno, String orderDate) {
		super();
		this.orderno = orderno;
		this.ordermname = ordermname;
		this.ordermcount = ordermcount;
		this.ordermprice = ordermprice;
		this.ordertbno = ordertbno;
		this.orderDate = orderDate;
	}

	public int getOrderno() {
		return orderno;
	}

	public void setOrderno(int orderno) {
		this.orderno = orderno;
	}

	public String getOrdermname() {
		return ordermname;
	}

	public void setOrdermname(String ordermname) {
		this.ordermname = ordermname;
	}

	public int getOrdermcount() {
		return ordermcount;
	}

	public void setOrdermcount(int ordermcount) {
		this.ordermcount = ordermcount;
	}

	public int getOrdermprice() {
		return ordermprice;
	}

	public void setOrdermprice(int ordermprice) {
		this.ordermprice = ordermprice;
	}

	public int getOrdertbno() {
		return ordertbno;
	}

	public void setOrdertbno(int ordertbno) {
		this.ordertbno = ordertbno;
	}
	
	

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	@Override
	public String toString() {
		return "OrderVO [orderno=" + orderno + ", ordermname=" + ordermname + ", ordermcount=" + ordermcount
				+ ", ordermprice=" + ordermprice + ", ordertbno=" + ordertbno + ", orderDate=" + orderDate
				+ ", toString()=" + super.toString() + "]";
	}

	
	

}
