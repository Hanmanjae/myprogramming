package controller;

import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.ParsePosition;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;

import application.Main;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import model.OrderVO;

public class OrderController implements Initializable {

	@FXML
	private TableView<OrderVO> orderTB;
	@FXML
	private TableColumn<OrderVO, Integer> noColumn;
	@FXML
	private TableColumn<OrderVO, Integer> tableColumn;
	@FXML
	private TableColumn<OrderVO, String> nameColumn;
	@FXML
	private TableColumn<OrderVO, Integer> countColumn;
	@FXML
	private TableColumn<OrderVO, Integer> priceColumn;
	@FXML
	private TableColumn<OrderVO, String> dateColumn;
	@FXML
	private Button btnMenu1;
	@FXML
	private Button btnMenu2;
	@FXML
	private Button btnMenu3;
	@FXML
	private Button btnMenu4;
	@FXML
	private Button btnMenu5;
	@FXML
	private Button btnMenu6;
	@FXML
	private Button btnMenu7;
	@FXML
	private Button btnMenu8;
	@FXML
	private Button btnMenu9;
	@FXML
	private Button btnMenu10;
	@FXML
	private Button btnMenu11;
	@FXML
	private Button btnMenu12;
	@FXML
	private Button btnMenu13;
	@FXML
	private Button btnMenu14;
	@FXML
	private Button btnMenu15;
	@FXML
	private Button btnMenu16;
	@FXML
	private Button btnMenu17;
	@FXML
	private Button btnMenu18;
	@FXML
	private Button btnMenu19;
	@FXML
	private Button btnMenu20;
	@FXML
	private Button btnMenu21;
	@FXML
	private Button btnMenu22;
	@FXML
	private Button btnMenu23;
	@FXML
	private Button btnMenu24;
	@FXML
	private Button btnMenu25;
	@FXML
	private Button btnMenu26;
	@FXML
	private Button btnMenu27;
	@FXML
	private Button btnMenu28;
	@FXML
	private Button btnMenu29;
	@FXML
	private Button btnMenu30;
	@FXML
	private Button btnMenu31;
	@FXML
	private Button btnMenu32;
	@FXML
	private Button btnMenu33;
	@FXML
	private Button btnMenu34;
	@FXML
	private Button btnMenu35;
	@FXML
	private Button btnMenu36;
	@FXML
	private Button btnMenu37;
	@FXML
	private Button btnMenupan;
	@FXML
	private Button btnDelete;
	@FXML
	private Button btnOk;
	@FXML
	private Button btnPlus1;
	@FXML
	private Button btnMinus1;
	@FXML
	private TextField txtTableNo;

	ObservableList<OrderVO> data = FXCollections.observableArrayList();

	
	int orderno;
	int ordertbno;
    int selectedIndex;
	int index = 0;
    String menuName;
	String orderDate;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		//���̺���ȣ�� ���� ��Ʈ�ѷ� holeNumber���� �ҷ�����
		txtTableNo.setText(MainController.holeNumber);

		btnDelete.setOnAction(event -> handlerBtnDeleteAction(event));
		btnOk.setOnAction(event -> handlerBtnOkAction(event));
		btnMenu1.setOnAction(event -> handlerBtnMenu1Action(event));
		btnMenu2.setOnAction(event -> handlerBtnMenu2Action(event));
		btnMenu3.setOnAction(event -> handlerBtnMenu3Action(event));
		btnMenu4.setOnAction(event -> handlerBtnMenu4Action(event));
		btnMenu5.setOnAction(event -> handlerBtnMenu5Action(event));
		btnMenu6.setOnAction(event -> handlerBtnMenu6Action(event));
		btnMenu7.setOnAction(event -> handlerBtnMenu7Action(event));
		btnMenu8.setOnAction(event -> handlerBtnMenu8Action(event));
		btnMenu9.setOnAction(event -> handlerBtnMenu9Action(event));
		btnMenu10.setOnAction(event -> handlerBtnMenu10Action(event));
		btnMenu11.setOnAction(event -> handlerBtnMenu11Action(event));
		btnMenu12.setOnAction(event -> handlerBtnMenu12Action(event));
		btnMenu13.setOnAction(event -> handlerBtnMenu13Action(event));
		btnMenu14.setOnAction(event -> handlerBtnMenu14Action(event));
		btnMenu15.setOnAction(event -> handlerBtnMenu15Action(event));
		btnMenu16.setOnAction(event -> handlerBtnMenu16Action(event));
		btnMenu17.setOnAction(event -> handlerBtnMenu17Action(event));
		btnMenu18.setOnAction(event -> handlerBtnMenu18Action(event));
		btnMenu19.setOnAction(event -> handlerBtnMenu19Action(event));
		btnMenu20.setOnAction(event -> handlerBtnMenu20Action(event));
		btnMenu21.setOnAction(event -> handlerBtnMenu21Action(event));
		btnMenu22.setOnAction(event -> handlerBtnMenu22Action(event));
		btnMenu23.setOnAction(event -> handlerBtnMenu23Action(event));
		btnMenu24.setOnAction(event -> handlerBtnMenu24Action(event));
		btnMenu25.setOnAction(event -> handlerBtnMenu25Action(event));
		btnMenu26.setOnAction(event -> handlerBtnMenu26Action(event));
		btnMenu27.setOnAction(event -> handlerBtnMenu27Action(event));
		btnMenu28.setOnAction(event -> handlerBtnMenu28Action(event));
		btnMenu29.setOnAction(event -> handlerBtnMenu29Action(event));
		btnMenu30.setOnAction(event -> handlerBtnMenu30Action(event));
		btnMenu31.setOnAction(event -> handlerBtnMenu31Action(event));
		btnMenu32.setOnAction(event -> handlerBtnMenu32Action(event));
		btnMenu33.setOnAction(event -> handlerBtnMenu33Action(event));
		btnMenu34.setOnAction(event -> handlerBtnMenu34Action(event));
		btnMenu35.setOnAction(event -> handlerBtnMenu35Action(event));
		btnMenu36.setOnAction(event -> handlerBtnMenu36Action(event));
		btnMenu37.setOnAction(event -> handlerBtnMenu37Action(event));

		orderTB.setEditable(true); //order���̺��� ���� ����

		nameColumn.setCellValueFactory(new PropertyValueFactory<>("ordermname"));
		countColumn.setCellValueFactory(new PropertyValueFactory<>("ordermcount"));
		priceColumn.setCellValueFactory(new PropertyValueFactory<>("ordermprice"));
		noColumn.setCellValueFactory(new PropertyValueFactory<>("orderno"));
		tableColumn.setCellValueFactory(new PropertyValueFactory<>("ordertbno"));
		dateColumn.setCellValueFactory(new PropertyValueFactory<>("orderDate"));

		orderTB.setItems(data);

		//���̺���ȣ�� ���ڸ� �Է°���
		DecimalFormat format = new DecimalFormat("##");
		txtTableNo.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}

			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 3) {
				return null;
			} else {
				return event;
			}
		}));

	}

	//��ü����Ʈ
	public void totallist(int tableNo, OrderVO oVo) {

		Object[][] totalData;

		OrderDAO oDao = new OrderDAO();

		ArrayList<String> title;
		ArrayList<OrderVO> list;

		title = oDao.getColumnName();
		int columnCount = title.size();

		list = oDao.getOrder(tableNo); //���̺� ��ȣ���� ���̺��並 �ޱ� ���ؼ� 
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			//�ߺ��ؼ� ������ �����͸� ���� ���ؼ� 
			data.remove(oVo);
			oVo = list.get(index);
			data.add(oVo);
		}

	}

	//1���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu1Action(ActionEvent event) {

		menuName = "�Ƚ�"; //�޴��̸�
		int price;  //�޴�����
		int count = 1; //�޴�����

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName); //�޴��̸����� ���� ������

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString(); //���糯¥

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";
	}

	//2���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu2Action(ActionEvent event) {
		menuName = "�ٸ���";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();
		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//3���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu3Action(ActionEvent event) {
		menuName = "������";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//4���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu4Action(ActionEvent event) {
		menuName = "�Ƚɰ�����";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//5���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu5Action(ActionEvent event) {
		menuName = "�ٸ��������";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//6���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu6Action(ActionEvent event) {
		menuName = "�Ƚ�set";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//7���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu7Action(ActionEvent event) {
		menuName = "�ٸ���set";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);

		menuName = "";

	}

	//8���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu8Action(ActionEvent event) {
		menuName = "������set";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//9���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu9Action(ActionEvent event) {
		menuName = "�Ƚɰ�����set";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//10���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu10Action(ActionEvent event) {
		menuName = "�ٸ��������set";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//11���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu11Action(ActionEvent event) {
		menuName = "������(��)";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//12���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu12Action(ActionEvent event) {
		menuName = "������(��)";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//13���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu13Action(ActionEvent event) {
		menuName = "ó��ó��";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//14���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu14Action(ActionEvent event) {
		menuName = "���̽�fresh";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//15���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu15Action(ActionEvent event) {
		menuName = "�ڸ����̽�";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//16���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu16Action(ActionEvent event) {
		menuName = "�̽�����";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//17���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu17Action(ActionEvent event) {
		menuName = "������";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//18���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu18Action(ActionEvent event) {
		menuName = "����Ĩ";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//19���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu19Action(ActionEvent event) {
		menuName = "�ڿｽ��";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//20���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu20Action(ActionEvent event) {
		menuName = "���ڻ�����";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//21���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu21Action(ActionEvent event) {
		menuName = "�ݶ�";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//22���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu22Action(ActionEvent event) {
		menuName = "���̴�";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//23���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu23Action(ActionEvent event) {
		menuName = "ȯŸ������";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//24���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu24Action(ActionEvent event) {
		menuName = "ȯŸ���ξ���";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//25���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu25Action(ActionEvent event) {
		menuName = "��ġ������";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//26���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu26Action(ActionEvent event) {
		menuName = "��ġ������";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//27���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu27Action(ActionEvent event) {
		menuName = "ġŲ�߰�(100g)";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//28���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu28Action(ActionEvent event) {
		menuName = "�ҽ��߰�(����)";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//29���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu29Action(ActionEvent event) {
		menuName = "�����̵�";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//30���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu30Action(ActionEvent event) {
		menuName = "�������̵�";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//31���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu31Action(ActionEvent event) {
		menuName = "�ڸ����̵�";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//32���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu32Action(ActionEvent event) {
		menuName = "û�������̵�";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//33���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu33Action(ActionEvent event) {
		menuName = "ȣ����";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//34���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu34Action(ActionEvent event) {
		menuName = "�ƻ���";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//35���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu35Action(ActionEvent event) {
		menuName = "��׽�";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//36���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu36Action(ActionEvent event) {
		menuName = "�ڸ�����";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//37���޴� Ŭ���̺�Ʈ
	public void handlerBtnMenu37Action(ActionEvent event) {
		menuName = "û��������";
		int price;
		int count = 1;

		MenuDAO mdao = new MenuDAO();

		price = mdao.getMenu(menuName);

		int tableNo = Integer.parseInt(txtTableNo.getText().trim());
		orderDate = LocalDate.now().toString();

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = new OrderVO(menuName, count, price, tableNo, orderDate);

		try {
			oDao.getOrderAdding(oVo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		totallist(tableNo, oVo);
		menuName = "";

	}

	//order���̺��� ���پ� �����
	public void handlerBtnDeleteAction(ActionEvent event) {

		selectedIndex = orderTB.getSelectionModel().getSelectedIndex();//������ ��

		OrderDAO odao = new OrderDAO();

		try {
			orderno = orderTB.getSelectionModel().getSelectedItem().getOrderno();//�ֹ���ȣ
			odao.getOrderInfoCellDelete(orderno);
			data.remove(selectedIndex);//������ �� �����

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//Ȯ�ι�ư �׼�
	public void handlerBtnOkAction(ActionEvent event) {
		try {
			//Ȯ�ι�ư ������ contents�� �̵�
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/contents.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�ֹ� ����");
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnOk.getScene().getWindow();
			oldStage.close();//���� ȭ�� �ݱ�
			mainMtage.show();//���ο� ȭ�� ����
		} catch (IOException e) {
			System.err.println("����" + e);
		}
	}

}
