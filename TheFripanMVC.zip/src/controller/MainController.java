package controller;

import java.net.URL;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;

import javafx.stage.Stage;

import model.OrderVO;

public class MainController implements Initializable {

	@FXML
	private TextField txtTime;
	@FXML
	private TextField txtSales;
	@FXML
	private Button btnSales;
	@FXML
	private Button btnH1;
	@FXML
	private Button btnH2;
	@FXML
	private Button btnH3;
	@FXML
	private Button btnH4;
	@FXML
	private Button btnH5;
	@FXML
	private Button btnH6;
	@FXML
	private Button btnH7;
	@FXML
	private Button btnH8;
	@FXML
	private Button btnH9;
	@FXML
	private Button btnH10;
	@FXML
	private Button btnH11;
	@FXML
	private Button btnH12;
	@FXML
	private Button btnBp1;
	@FXML
	private Button btnBp2;
	@FXML
	private Button btnBp3;
	@FXML
	private Button btnBp4;

	public static String holeNumber; // ���̺���ȣ

	OrderDAO odao = new OrderDAO();
	String orderDate; // ��¥
	int sales; // ����

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		btnH1.setOnAction(event -> handlerBtnH1Action(event));
		btnH2.setOnAction(event -> handlerBtnH2Action(event));
		btnH3.setOnAction(event -> handlerBtnH3Action(event));
		btnH4.setOnAction(event -> handlerBtnH4Action(event));
		btnH5.setOnAction(event -> handlerBtnH5Action(event));
		btnH6.setOnAction(event -> handlerBtnH6Action(event));
		btnH7.setOnAction(event -> handlerBtnH7Action(event));
		btnH8.setOnAction(event -> handlerBtnH8Action(event));
		btnH9.setOnAction(event -> handlerBtnH9Action(event));
		btnH10.setOnAction(event -> handlerBtnH10Action(event));
		btnH11.setOnAction(event -> handlerBtnH11Action(event));
		btnH12.setOnAction(event -> handlerBtnH12Action(event));
		btnBp1.setOnAction(event -> handlerBtnBp1Action(event));
		btnBp2.setOnAction(event -> handlerBtnBp2Action(event));
		btnBp3.setOnAction(event -> handlerBtnBp3Action(event));
		btnBp4.setOnAction(event -> handlerBtnBp4Action(event));

		btnSales.setOnAction(event -> handlerBtnSalesAction(event));
		// ���ó�¥ ��,��,��,�ð�,��,�� ����
		txtTime.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

		orderDate = LocalDate.now().toString(); // ���ó�¥

	}

	//�����ư Ŭ�� �̺�Ʈ
	public void handlerBtnSalesAction(ActionEvent event) {

		try {
			sales = odao.getSales(orderDate);
			txtSales.setText(sales + ""); //������ sales�ؽ�Ʈ�ʵ忡 ������
		} catch (Exception e) {

		}
	}

	// ���/����4 Ȧ��ư Ŭ���̺�Ʈ 
	public void handlerBtnBp4Action(ActionEvent event) {
		try {
			holeNumber = "16"; //���̺���ȣ 16
			//contents��� �̵�
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnBp4.getScene().getWindow();
			oldStage.close(); //����ȭ�� �ݱ�
			mainStage.show(); //�������� ȭ�� �����ֱ�

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ���/����3 Ȧ��ư Ŭ���̺�Ʈ
	public void handlerBtnBp3Action(ActionEvent event) {
		try {
			holeNumber = "15";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnBp3.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ���/����2 Ȧ��ư Ŭ���̺�Ʈ
	public void handlerBtnBp2Action(ActionEvent event) {
		try {
			holeNumber = "14";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnBp2.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ���/����1 Ȧ��ư Ŭ���̺�Ʈ
	public void handlerBtnBp1Action(ActionEvent event) {
		try {

			holeNumber = "13";

			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnBp1.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ12 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH12Action(ActionEvent event) {
		try {
			holeNumber = "12";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH12.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ11 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH11Action(ActionEvent event) {
		try {
			holeNumber = "11";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH11.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ10 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH10Action(ActionEvent event) {
		try {
			holeNumber = "10";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH10.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ9 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH9Action(ActionEvent event) {
		try {
			holeNumber = "9";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH9.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ8 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH8Action(ActionEvent event) {
		try {
			holeNumber = "8";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH8.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ7 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH7Action(ActionEvent event) {
		try {
			holeNumber = "7";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH7.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ6 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH6Action(ActionEvent event) {
		try {
			holeNumber = "6";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH6.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ5 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH5Action(ActionEvent event) {
		try {
			holeNumber = "5";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH5.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ4 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH4Action(ActionEvent event) {
		try {
			holeNumber = "4";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH4.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ3 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH3Action(ActionEvent event) {
		try {
			holeNumber = "3";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH3.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ2 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH2Action(ActionEvent event) {
		try {
			holeNumber = "2";
			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH2.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Ȧ1 ��ư Ŭ���̺�Ʈ
	public void handlerBtnH1Action(ActionEvent event) {
		try {
			holeNumber = "1";

			Parent root = FXMLLoader.load(getClass().getResource("/view/contents.fxml"));
			Scene scene = new Scene(root);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ֹ� ����");
			mainStage.setScene(scene);
			Stage oldStage = (Stage) btnH1.getScene().getWindow();
			oldStage.close();
			mainStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
