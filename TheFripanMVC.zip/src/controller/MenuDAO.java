package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.MenuVO;
import model.OrderVO;

public class MenuDAO {
	
	//�޴��̸����� �޴����� �ҷ�����
	public int getMenu(String menuName) {
		
		StringBuffer sql = new StringBuffer();
		sql.append("select menuprice from menu where menuname = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int menuprice =0;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, menuName);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				menuprice = rs.getInt("menuprice");
			}

		} catch (SQLException se) {

		} catch (Exception e) {

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}

		}
		return menuprice;
	}
}
