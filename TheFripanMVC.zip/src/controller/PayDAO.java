package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.PayVO;

public class PayDAO {

	// �������� ���
	public void getPayInfo(PayVO pvo) throws Exception {

		StringBuffer sql = new StringBuffer();
		sql.append("insert into payinfo (ordertbno,payall,payreceived,payreceive,paychange,orderdate)");
		sql.append("values (?,?,?,?,?,to_char(sysdate,'yyyy/mm/dd, hh24:mi:ss'))");

		Connection con = null;
		PreparedStatement pstmt = null;
		PayVO pVo = pvo;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());

			System.out.println(pVo);

			pstmt.setInt(1, pVo.getOrdertbno());
			pstmt.setInt(2, pVo.getPayall());
			pstmt.setInt(3, pVo.getPayreceived());
			pstmt.setInt(4, pVo.getPayreceive());
			pstmt.setInt(5, pVo.getPaychange());

			int i = pstmt.executeUpdate();

		} catch (SQLException se) {

		} catch (Exception e) {

		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}

	}

}
