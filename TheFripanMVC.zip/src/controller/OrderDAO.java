package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import controller.DBUtil;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import model.OrderVO;

public class OrderDAO {

	// ���̺���ȣ���� �ֹ��� ������ �� ���ϱ�
	public int getOrderSum(int ordertbno) throws Exception {

		StringBuffer sql = new StringBuffer();
		sql.append("select sum(ordermprice) as sum from orderinfo where ordertbno = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int sum = 0;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, ordertbno);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				sum = rs.getInt("sum");
			}

		} catch (SQLException se) {

		} catch (Exception e) {

		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return sum;

	}

	// �ֹ���ȣ���� �����ϱ�
	public void getOrderInfoCellDelete(int orderno) throws Exception {

		StringBuffer sql = new StringBuffer();
		sql.append("delete from orderinfo where orderno = ?");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, orderno);
			int i = pstmt.executeUpdate();
		} catch (SQLException se) {

		} catch (Exception e) {

		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}

	}

	// �ֹ��������� ����ϱ�
	public void getOrderAdding(OrderVO ovo) throws Exception {

		StringBuffer sql = new StringBuffer();
		sql.append("insert into orderinfo (orderno,ordertbno,ordermname,ordermcount,ordermprice,orderdate)");
		sql.append("values (orderinfo_seq.nextval,?,?,?,?,sysdate)");

		Connection con = null;
		PreparedStatement pstmt = null;
		OrderVO oVo = ovo;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());

			System.out.println(oVo);

			pstmt.setInt(1, oVo.getOrdertbno());
			pstmt.setString(2, oVo.getOrdermname());
			pstmt.setInt(3, oVo.getOrdermcount());
			pstmt.setInt(4, oVo.getOrdermprice());

			int i = pstmt.executeUpdate();

		} catch (SQLException se) {

		} catch (Exception e) {

		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}

	}

	// ���̺����� ����Ʈ �޾ƿ���
	public ArrayList<OrderVO> getOrder(int ordertbno) {
		ArrayList<OrderVO> list = new ArrayList<OrderVO>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from orderinfo where ordertbno = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		OrderVO oVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, ordertbno);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				oVo = new OrderVO();
				oVo.setOrderno(rs.getInt("orderno"));
				oVo.setOrdermname(rs.getString("ordermname"));
				oVo.setOrdermcount(rs.getInt("ordermcount"));
				oVo.setOrdermprice(rs.getInt("ordermprice"));
				oVo.setOrdertbno(rs.getInt("ordertbno"));
				oVo.setOrderDate(rs.getString("orderdate"));
				list.add(oVo);
			}

		} catch (SQLException se) {

		} catch (Exception e) {

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}

		}
		return list;
	}

	// �÷��̸� �޾ƿ���
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		StringBuffer sql = new StringBuffer();
		sql.append("select * from orderinfo");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// resultsetmetadata ��ü ���� ����
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return columnName;
	}

	// ���̺���ȣ���� ������ �����ϱ�
	public void getOrderDelete(int ordertbno) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from orderinfo where ordertbno = ?");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, ordertbno);
			int i = pstmt.executeUpdate();
		} catch (SQLException se) {

		} catch (Exception e) {

		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}

	}

	// ��¥���� ���� ���ϱ�
	public int getSales(String orderDate) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("select sum(ordermprice) as sum from orderinfo");
		sql.append(" where to_date(orderdate,'yyyy-mm-dd') = to_date(sysdate,'yyyy-mm-dd')");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int sum = 0;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				sum = rs.getInt("sum");
			}

		} catch (SQLException se) {

		} catch (Exception e) {

		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return sum;

	}

}
